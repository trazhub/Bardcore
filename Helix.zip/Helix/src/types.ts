export enum SearchEngine {
    YouTube = 'ytsearch',
    SoundCloud = 'scsearch',
    YouTubeMusic = 'ytmsearch',
}
